# SquareLine Example Project templete

> ui code will generated in `./main/ui`
